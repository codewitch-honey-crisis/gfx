#pragma once
void test_multiple_linkage();