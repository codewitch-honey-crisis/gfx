#define MINIZ_HEADER_FILE_ONLY
#include "../src/miniz.c"
